(function(global) {
  const summernote = global.summernote;
  if (!summernote) {
    return;
  }

  const registries = [];
  summernote.lang = summernote.lang || {};
  registries.push(summernote.lang);
  if (summernote.summernote) {
    summernote.summernote.lang = summernote.summernote.lang || {};
    if (summernote.summernote.lang !== summernote.lang) {
      registries.push(summernote.summernote.lang);
    }
  }
  registries.forEach((registry) => { registry["de-DE"] = {
  "font": {
    "bold": "Fett",
    "italic": "Kursiv",
    "underline": "Unterstrichen",
    "clear": "Schriftstil entfernen",
    "height": "Zeilenhöhe",
    "name": "Schriftfamilie",
    "strikethrough": "Durchgestrichen",
    "subscript": "Tiefgestellt",
    "superscript": "Hochgestellt",
    "size": "Schriftgröße",
    "sizeunit": "Einheit der Schriftgröße"
  },
  "image": {
    "image": "Bild",
    "insert": "Bild einfügen",
    "resizeFull": "Originalgröße",
    "resizeHalf": "Halbe Größe",
    "resizeQuarter": "Viertelgröße",
    "resizeNone": "Originalgröße",
    "floatLeft": "Links ausrichten",
    "floatRight": "Rechts ausrichten",
    "floatNone": "Ausrichtung entfernen",
    "shapeRounded": "Form: Abgerundet",
    "shapeCircle": "Form: Kreis",
    "shapeThumbnail": "Form: Vorschaubild",
    "shapeNone": "Form: Keine",
    "dragImageHere": "Bild oder Text hierher ziehen",
    "dropImage": "Bild oder Text ablegen",
    "selectFromFiles": "Aus Dateien auswählen",
    "maximumFileSize": "Maximale Dateigröße",
    "maximumFileSizeError": "Maximale Dateigröße überschritten.",
    "url": "Bild-URL",
    "remove": "Bild entfernen",
    "original": "Original"
  },
  "video": {
    "video": "Video",
    "videoLink": "Videolink",
    "insert": "Video einfügen",
    "play": "Abspielen",
    "resizeFull": "Originalgröße",
    "resizeHalf": "Halbe Größe",
    "resizeQuarter": "Viertelgröße",
    "resizeNone": "Originalgröße",
    "floatLeft": "Links ausrichten",
    "floatRight": "Rechts ausrichten",
    "floatNone": "Ausrichtung entfernen",
    "url": "Video-URL",
    "remove": "Video entfernen",
    "providers": "(YouTube, Google Drive, Vimeo, Vine, Instagram, DailyMotion, Youku, Peertube)"
  },
  "link": {
    "link": "Link",
    "insert": "Link einfügen",
    "unlink": "Link entfernen",
    "edit": "Bearbeiten",
    "textToDisplay": "Anzuzeigender Text",
    "url": "Zu welcher URL soll dieser Link führen?",
    "openInNewWindow": "In neuem Fenster öffnen"
  },
  "table": {
    "table": "Tabelle",
    "addRowAbove": "Zeile oberhalb einfügen",
    "addRowBelow": "Zeile unterhalb einfügen",
    "addColLeft": "Spalte links einfügen",
    "addColRight": "Spalte rechts einfügen",
    "delRow": "Zeile löschen",
    "delCol": "Spalte löschen",
    "delTable": "Tabelle löschen"
  },
  "hr": {
    "insert": "Horizontale Linie einfügen"
  },
  "style": {
    "style": "Stil",
    "p": "Normal",
    "blockquote": "Zitat",
    "pre": "Code",
    "h1": "Überschrift 1",
    "h2": "Überschrift 2",
    "h3": "Überschrift 3",
    "h4": "Überschrift 4",
    "h5": "Überschrift 5",
    "h6": "Überschrift 6"
  },
  "lists": {
    "unordered": "Unsortierte Liste",
    "ordered": "Sortierte Liste"
  },
  "options": {
    "help": "Hilfe",
    "fullscreen": "Vollbild",
    "codeview": "Codeansicht"
  },
  "paragraph": {
    "paragraph": "Absatz",
    "outdent": "Einzug verkleinern",
    "indent": "Einzug vergrößern",
    "left": "Linksbündig",
    "center": "Zentriert",
    "right": "Rechtsbündig",
    "justify": "Blocksatz"
  },
  "color": {
    "recent": "Zuletzt verwendete Farbe",
    "more": "Weitere Farben",
    "background": "Hintergrundfarbe",
    "foreground": "Textfarbe",
    "transparent": "Transparent",
    "setTransparent": "Transparent setzen",
    "reset": "Zurücksetzen",
    "resetToDefault": "Auf Standard zurücksetzen",
    "cpSelect": "Auswählen",
    "colorsName": [
      [
        "Schwarz",
        "Dunkelgrau",
        "Taubengrau",
        "Sternenstaub",
        "Blassschiefer",
        "Galerie",
        "Alabaster",
        "Weiß"
      ],
      [
        "Rot",
        "Orangenschale",
        "Gelb",
        "Grün",
        "Cyan",
        "Blau",
        "Elektrisches Violett",
        "Magenta"
      ],
      [
        "Azalee",
        "Apricot",
        "Eierschale",
        "Zartgrün",
        "Botticelli",
        "Tropenblau",
        "Mischka",
        "Dämmerung"
      ],
      [
        "Rosa",
        "Pfirsichorange",
        "Creme Brulee",
        "Spross",
        "Casper",
        "Perano",
        "Kühles Lila",
        "Rosagrau"
      ],
      [
        "Korallrot",
        "Rajah",
        "Löwenzahn",
        "Olivgrün",
        "Golfstrom",
        "Wikingerblau",
        "Blaue Margerite",
        "Puce"
      ],
      [
        "Wachrot",
        "Feuerbusch",
        "Goldtraum",
        "Chelsea-Gurke",
        "Schmachtblau",
        "Boston-Blau",
        "Schmetterlingsbusch",
        "Cadillac"
      ],
      [
        "Sangria",
        "Mai Tai",
        "Buddha-Gold",
        "Waldgrün",
        "Eden",
        "Venedig-Blau",
        "Meteorit",
        "Bordeaux"
      ],
      [
        "Rosenholz",
        "Zimt",
        "Olive",
        "Petersilie",
        "Tiber",
        "Mitternachtsblau",
        "Valentino",
        "Loulou"
      ]
    ]
  },
  "shortcut": {
    "shortcuts": "Tastenkürzel",
    "close": "Schließen",
    "textFormatting": "Textformatierung",
    "action": "Aktion",
    "paragraphFormatting": "Absatzformatierung",
    "documentStyle": "Dokumentstil",
    "extraKeys": "Weitere Tasten"
  },
  "help": {
    "escape": "Escape",
    "insertParagraph": "Absatz einfügen",
    "undo": "Letzte Aktion rückgängig machen",
    "redo": "Letzte Aktion wiederholen",
    "tab": "Tab",
    "untab": "Einzug entfernen",
    "bold": "Fett formatieren",
    "italic": "Kursiv formatieren",
    "underline": "Unterstreichen",
    "strikethrough": "Durchstreichen",
    "removeFormat": "Formatierung entfernen",
    "justifyLeft": "Linksbündig ausrichten",
    "justifyCenter": "Zentriert ausrichten",
    "justifyRight": "Rechtsbündig ausrichten",
    "justifyFull": "Im Blocksatz ausrichten",
    "insertUnorderedList": "Unsortierte Liste umschalten",
    "insertOrderedList": "Sortierte Liste umschalten",
    "outdent": "Aktuellen Absatz ausrücken",
    "indent": "Aktuellen Absatz einrücken",
    "formatPara": "Aktuellen Block als Absatz (P-Tag) formatieren",
    "formatH1": "Aktuellen Block als H1 formatieren",
    "formatH2": "Aktuellen Block als H2 formatieren",
    "formatH3": "Aktuellen Block als H3 formatieren",
    "formatH4": "Aktuellen Block als H4 formatieren",
    "formatH5": "Aktuellen Block als H5 formatieren",
    "formatH6": "Aktuellen Block als H6 formatieren",
    "insertHorizontalRule": "Horizontale Linie einfügen",
    "linkDialog.show": "Linkdialog anzeigen"
  },
  "history": {
    "undo": "Rückgängig",
    "redo": "Wiederholen"
  },
  "specialChar": {
    "specialChar": "SONDERZEICHEN",
    "select": "Sonderzeichen auswählen"
  },
  "output": {
    "noSelection": "Keine Auswahl getroffen!"
  },
  "helpDialog": {
    "brand": "Summernote Next",
    "platform": {
      "mac": "macOS",
      "pc": "Windows und Linux"
    },
    "links": {
      "examples": "Beispiele",
      "project": "Projekt",
      "issues": "Probleme"
    }
  }
}; });
})(globalThis);
